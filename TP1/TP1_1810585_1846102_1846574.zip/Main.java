/**
 * Classe Main
 * 
 * Samuel D'Amours-Fortier, Justine Lambert et Julie Rousseau
 * LOG2810 : Structures discrètes
 * 
 * Classe principale du programme
 **/


public class Main {

	public static void main(String[] args) {
		
		Menu menuPrincipal = new Menu();
		menuPrincipal.Afficher();
		System.exit(0);
	}
}